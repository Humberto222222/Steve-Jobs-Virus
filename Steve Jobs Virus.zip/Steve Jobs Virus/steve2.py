import os
import tkinter as tk
from PIL import Image, ImageTk

# Obtém o diretório atual do script
diretorio_atual = os.path.dirname(os.path.abspath(__file__))

# Constrói o caminho completo para a imagem "steve.jfif"
caminho_imagem = os.path.join(diretorio_atual, "steve.jfif")

def exibir_nova_janela_com_foto():
    root = tk.Tk()
    root.title("Steve Jobs")

    # Carrega a imagem
    imagem = Image.open(caminho_imagem)
    imagem = ImageTk.PhotoImage(imagem)

    # Cria um widget de rótulo para exibir a imagem
    label_imagem = tk.Label(root, image=imagem)
    label_imagem.pack()

    root.mainloop()

# Chama a função para exibir a nova janela com a foto
exibir_nova_janela_com_foto()
