import tkinter as tk
from tkinter import scrolledtext
import colorama
from colorama import Fore

colorama.init()

# Novo texto colorido em vermelho
novo_texto = """
                                                            
                        .:~!!!~^.                           
                    ^7YPGB###&##BGY7^                       
                 :?P#####BBBBBB######P!.                    
                ?B&#GPPPGGPPPPPPPPGGB##G!                   
              :P&#GJ7??JJJ???YY5555PGB###J                  
             :G&#G?!!!!~~^^^~!!?JY5PGGB###5.                
            .5###Y7!!~::...^^^!!?J5GGB####5.               
            .5B#BJ7!!~::...:::^!!?YPGBBBBBBB:               
             JGGPY7!!^^:::::::^~?JYPGBBBGBB~               
            !PP5JY77~^:::::::::^~!7JYPB##BB#5!              
           ~BPGP5???7~^:^^^^^^^^!7?JJ5GB##B#&&^             
           :PPGB57JYPP5P5YJ7~~?5PGGGGGGB####&G.             
            ?BPY??!?J7?55PJ!.^YB#PY55GBGBB##&Y              
            :YYY7~!~:::~!7~~:^JGG57!!?JJP##B#7              
             !7YY7!~^:^~~~:..:JGG5?!!7?5B###G:              
             .~7YYJ?7~^~~~::::?GBBY??YPB###5^               
               ~??JJ?!^^~^:^^^Y###GYYPB###B^                
               .!?77?!!7?77?Y5GB##BGGGBGB#G.                
                .7777?YPP5YJJY5PB###GPPGB#7                 
                 .~?YYPGJ77!7?JYPBBG5GBB#B:                 
                  .?Y55Y?77?YJYPGGP55#####P~.               
                   ~555J77?JYJYPP5JG###&&&&&GJ7!^.          
               .^?5B#BPPPGJ^:^~JB&&&&&&&&&&&&&BPY?~:     
           .^75G#&&##&&##J!~^::.^JG#&&&&&&&&&&&&&&&&&&&#GY!^.
        :!YB#&&&#######&#!^^^^:::?PB#&&&&&&&&&&&&&&&&&&&&&&&B
    :!JG#&&&##########&B?!^^:!?7J5G###&&&&&&&&&&&#####&&&&&&
:~JG#&&&&&&###########5?^^^~!Y55PPGB#&#&&&&&&&&#######&&&&&&
#&&&&&&##############5::^~7??YY5PPPG##&&&&&&&##############&
&&&&#&&##############5~~7JYJJYYYYPPGB##&&&&&&&############&&
&&&&####&#############PYYYYYYYYYY5P5PB##&&&&&&&&##########&#


"""

# Função para exibir o novo texto em uma janela separada
def exibir_novo_texto():
    root = tk.Tk()
    root.title("Steve Jobs")

    # Área de texto com rolagem
    texto_widget = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=80, height=40, font=("Courier New", 10))
    texto_widget.insert(tk.END, f"{Fore.RED}{novo_texto}{Fore.RESET}")
    texto_widget.configure(state='disabled')  # Impede a edição do texto
    texto_widget.pack(expand=True, fill='both')

    root.mainloop()

# Chama a função para exibir o novo texto na janela
exibir_novo_texto()