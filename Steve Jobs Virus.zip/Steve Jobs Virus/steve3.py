import tkinter as tk
from PIL import Image, ImageTk
import pygame

class JanelaMovivel:
    imagem_global = None  # Mantém uma referência global à imagem

    def __init__(self, root, largura_tela, altura_tela):
        self.root = root
        self.largura_tela = largura_tela
        self.altura_tela = altura_tela

        # Carrega a imagem e configura o Label
        if JanelaMovivel.imagem_global is None:
            JanelaMovivel.imagem_global = Image.open("steve.jfif")
            JanelaMovivel.imagem_global = ImageTk.PhotoImage(JanelaMovivel.imagem_global)

        self.label_imagem = tk.Label(root, image=JanelaMovivel.imagem_global)
        self.label_imagem.image = JanelaMovivel.imagem_global
        self.label_imagem.pack()

        # Configuração inicial da posição
        self.x = 0
        self.y = 0

        # Move a janela
        self.mover_janela()

        # Configura o evento de fechamento da janela
        root.protocol("WM_DELETE_WINDOW", self.criar_nova_janela)

        # Inicia a reprodução de áudio
        pygame.mixer.init()
        pygame.mixer.music.load("Music.mp3")
        pygame.mixer.music.play(-1)  # Repetir indefinidamente

    def mover_janela(self):
        # Move a janela para a posição atual
        self.root.geometry(f"+{self.x}+{self.y}")
        self.root.update()

        # Atualiza a posição para o próximo frame
        if 0 <= self.x < self.largura_tela:
            self.x += 5
            self.y = 0
        elif self.x >= self.largura_tela:
            self.x = 0
            self.y += 5

        # Chama novamente após um curto intervalo
        self.root.after(20, self.mover_janela)

    def criar_nova_janela(self):
        nova_root = tk.Toplevel(self.root)
        nova_root.title("Nova Janela com Imagem Móvel")

        # Cria uma nova instância da janela móvel
        nova_janela_movivel = JanelaMovivel(nova_root, self.largura_tela, self.altura_tela)

def main():
    # Configuração da janela principal
    root = tk.Tk()
    root.title("Janela com Imagem Móvel")
    root.geometry("200x200")  # Ajuste conforme necessário

    # Obtém as dimensões da tela
    largura_tela = root.winfo_screenwidth()
    altura_tela = root.winfo_screenheight()

    # Cria uma instância da janela móvel
    janela_movivel = JanelaMovivel(root, largura_tela, altura_tela)

    # Mantém o loop principal da interface gráfica
    root.mainloop()

if __name__ == "__main__":
    main()
